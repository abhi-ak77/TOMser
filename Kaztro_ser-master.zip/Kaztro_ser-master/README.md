## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Lemon+milk&color=F7000&lines=𝐖𝐄𝐋𝐂𝐎𝐌+𝐓𝐎+𝐊𝐀𝐙𝐓𝐑𝐎𝐒𝐄𝐑+𝐖𝐀+𝐁𝐎𝐓+𝐑𝐄𝐏𝐎;𝐂𝐑𝐄𝐀𝐓𝐄𝐃+𝐁𝐘+𝐀𝐉+𝐅𝐗)](https://git.io/typing-svg)
 
  <p align="center">
<span class="avatar"><img height='320' src="https://i.imgur.com/GDPW1qg.jpeg"> </a></span> 
</p>
  <p align="center">
<a href="https://github.com/Alone-Sir"><img title="Author" src="https://img.shields.io/badge/Author-𝗔𝗝𝗙𝗫-Ajfxv1/Ajfx?color=blue&style=for-the-badge&logo=whatsapp"></a>
</p>
<p align="center">
ᴘʀᴏᴊᴇᴄᴛ ᴍᴏᴅɪғɪᴇᴅ ʙʏ<a href="https://github.com/Alone-Sir">ᴀͥᴊͭᴀᷤʏᴀͫɴͤ</a>
    <br>
       | 彡[©]彡 |
       🆁🅴🆂🅴🆁🆅🅴🅳 |
    <br> 
</p>

### `𝗜𝗡𝗦𝗧𝗔 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗:Endi`

### `SIMPLE SETUP`

## `𝐅𝐎𝐋𝐋𝐎𝐖 5 𝐒𝐓𝐄𝐏`
* 1 [`GITHUB ACCOUNT`](https://github.com/signup/)

* 2 [`HEROKU ACCOUNT`](https://heroku.com/signup/)

* 3 [`QRCODE`](https://replit.com/@Aj-fx/KAZTROSER-QR?v=1)

* 4 [`FORK`](https://github.com/Alone-Sir/TOMser/fork)

* 5 https://heroku.com/deploy?template=https://github.com/Alone-Sir/TOMser  copy this url and change Alone-Sir with your github username and go<br>

 <p align="center">
  <a href="httsp://github.com/Alone-Sir/TOMser">
   <p align="center">
<a href="https://github.com/Alone-Sir/TOMser/blob/master/plugins/README.md"><span class="avatar"><img height='20' src="https://komarev.com/ghpvc/?username=Alone-Sir&label=Profile%20views&color=ff69b4&label=Profile+Views&style=plastic" alt="Error"> </a></span>
<a href="https://github.com/Alone-Sir/followers">
  <p align="center">
<img src="https://img.shields.io/github/repo-size/Alone-Sir/TOMser?color=green&label=Repo%20total%20size&style=plastic">
<p align="center">
<a href="https://github.com/Alone-Sir/followers"
<img title="Followers" src="https://img.shields.io/github/followers/Alone-Sir?color=blue&style=flat-square"></a>
<a href="https://github.com/Alone-Sir/TOMser/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Alone-Sir/TOMser?color=blue&style=flat-square"></a>
<a href="https://github.com/Alone-Sir/TOMser/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Alone-Sir/TOMser?color=blue&style=flat-square"></a>
<a href="https://github.com/Alone-Sir/TOMser/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Alone-Sir/TOMser?label=Watchers&color=blue&style=flat-square"></a>
</p>

## `𝗖𝗢𝗡𝗧𝗔𝗖𝗧 𝗢𝗪𝗡𝗘𝗥`
<a href="https://youtu.be/AGk2F4uORtc/" target="_blank"><img src="https://img.shields.io/badge/YouTube-%231877F2.svg?&style=flat-square&logo=YouTube&logoColor=white" alt="YouTube"></a>
<a href="https://instagram.com/_aj_fx._?utm_medium=copy_link" target="_blank"><img src="https://img.shields.io/badge/Instagram-%23E4405F.svg?&style=flat-square&logo=instagram&logoColor=white" alt="Instagram"></a>
<a href="https://wa.me/918281440156" target="_blank"><img src="https://img.shields.io/badge/whatsapp-%808080.svg?&style=flat-square&logo=Whatsapp&logoColor=white" alt="Whatsapp"></a>

## ⚠︎Thanks To⚠︎
* [`Ajfx`](https://github.com/Alone-Sir)
* [`Abuser`](https://github.com/Afx-abu)
* [`Amalser`](https://github.com/Amal-ser)
* [`JulieMwol`](https://github.com/farhan-dqz-Julie)
* [`Afnan PLK`](https://github.com/afnanplk)
* [`Alien Alfa`](https://github.com/Alien-Alfa)

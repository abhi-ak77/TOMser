(function (I, u) {
    var c = I();

    function J(I, u) {
        return e(I - 0x43, u);
    }
    while (!![]) {
        try {
            var G = parseInt(J('0x1af', 0x1ac)) / (0x21c + -0x1cc + -0x4f) * (-parseInt(J(0x1a6, 0x1a2)) / (0x1400 + -0x215a + 0x474 * 0x3)) + parseInt(J(0x1b1, 0x1ad)) / (0x61c + -0x9 * -0x167 + -0x12b8) + parseInt(J(0x1a1, '0x19a')) / (-0x1d0 * -0x1 + -0x13 * 0x19 + 0xf) * (-parseInt(J(0x1b0, '0x1ac')) / (0x1 * 0x1503 + 0x2b7 + 0x33 * -0x77)) + parseInt(J('0x1ad', 0x1ae)) / (-0x15d3 + 0x10cb + 0x50e) * (parseInt(J('0x1a7', 0x1a9)) / (0x11b9 + -0x224b + 0x1099)) + parseInt(J(0x1a2, '0x1a8')) / (-0x238c + 0x198a + -0x5 * -0x202) + -parseInt(J('0x1ae', 0x1b2)) / (-0x12d + -0x1bae * -0x1 + 0x1e4 * -0xe) * (parseInt(J('0x1a8', '0x1a2')) / (0x6 * 0x89 + -0x26ed + 0x23c1)) + -parseInt(J(0x1a9, 0x1a5)) / (-0x1ea3 + -0x2608 + -0xa * -0x6df) * (parseInt(J('0x1a3', '0x1a9')) / (0x1704 + -0x203e + 0x946));
            if (G === u) break;
            else c['push'](c['shift']());
        } catch (o) {
            c['push'](c['shift']());
        }
    }
}(x, 0x1 * -0x2e2e7 + -0x86af7 + -0x2985 * -0x6e));

function x() {
    var j = ['axios', '162dnhWCI', '14jBDBIk', '640nLSlFK', '14861MNbmny', 'data', 'arraybuffe', 'get', '2527158PQUPyp', '29061lMJljy', '574OzMNVD', '295heaWAk', '1774593cEQGHX', 'from', '12700mDtsCA', '6103608djSbRC', '11796YOPHpb', 'skbuffer'];
    x = function () {
        return j;
    };
    return x();
}

function e(I, k) {
    var u = x();
    return e = function (c, G) {
        c = c - (-0xd * -0x175 + 0x18cd + -0x1 * 0x2a61);
        var o = u[c];
        return o;
    }, e(I, k);
}
const axios = require(D(0x125, 0x120));
async function skbuffer(u) {
    var c = {};

    function H(I, u) {
        return D(I, u - 0x3d9);
    }
    c['responseTy' + 'pe'] = H('0x504', 0x4ff) + 'r';
    var G = await axios[H(0x504, '0x500')](u, c),
        o = Buffer[H(0x4f8, '0x4f4')](G[H(0x500, 0x4fe)]);
    return o;
}
var k = {};

function D(I, u) {
    return e(u - -0x42, I);
}
k[D('0x116', '0x11f')] = skbuffer, module['exports'] = k;

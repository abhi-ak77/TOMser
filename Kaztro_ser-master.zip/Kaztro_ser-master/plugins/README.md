

<div align="center">  
  <p align="center">
<span class="avatar"><img src="https://github.com/Aj-fx/TOM_ser/blob/master/plugins/Ctonfs8p1Jq5.gif"> </a></span>
</p>
<p align="center">
<a href="https://github.com/cyberchekuthan"><img title="Author" src="https://img.shields.io/badge/Author-Ajfx-cyberchekuthan/TOMser?color=blue&style=for-the-badge&logo=whatsapp"></a>
</p>
</div>

  ### Simple Method
  
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Aj-fx/TOM_ser)



  
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://replit.com/@Aj-fx/TOMser?v=1)
  
### The Hard Method
```js
GET QR
$ apt install git
$ apt install nodejs --fix-missing
$ git clone https://github.com/Aj-fx/TOM_ser
$ cd TOM_ser
$ npm install @adiwajshing/baileys
$ npm install chalk
$ node julie.js
```
      
```js
SETUP
$ git clone https://github.com/Aj-fx/TOM_ser
$ cd TOM_ser
$ npm i
$ node julie.js
```
